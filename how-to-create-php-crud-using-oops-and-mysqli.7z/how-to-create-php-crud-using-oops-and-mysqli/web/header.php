<html>
<head>
<title>How to Create PHP Crud using OOPS and MySQLi</title>
<link href="web/css/style.css" type="text/css" rel="stylesheet" />
</head>
<body>
    <h2>How to Create PHP Crud using OOPS and MySQLi</h2>
    <div>
        <ul class="menu-list">
            <li><a href="index.php">Student</a></li>
            <li><a href="index.php?action=attendance">Attendance</a></li>
        </ul>
    </div>